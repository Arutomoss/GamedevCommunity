<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>


<body>
    <table id="dtMaterialDesignExample" class="table table-striped" cellspacing="10">
        <thead>
            <tr>
                <th class="th-sm">ID
                </th>
                <th class="th-sm">Название блюда
                </th>
                <th class="th-sm">Вес
                </th>
                <th class="th-sm">Цена
                </th>
                <th class="th-sm">Категория
                </th>
            </tr>
        </thead>
        <tbody>

            <?php
                $conn = mysqli_connect("localhost", "root", "", "cafe");

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT dish_id, dish_name, dish_weight, dish_price, dish_categor FROM `dishes`";

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {

                        echo "<tr><td>" . $row["dish_id"]
                            . "</td><td>" . $row["dish_name"]
                            . "</td><td>" . $row["dish_weight"]
                            . "</td><td>" . $row["dish_price"]
                            . "</td><td>" . $row["dish_categor"]
                            . "</td></tr>";
                    }
                    echo "</tbody>";
                } else {
                    echo "0 results";
                }
                $conn->close();
            ?>


    <table id="dtMaterialDesignExample" class="table table-striped" cellspacing="10">
        <thead>
            <tr>
                <th class="th-sm">ID заказа
                </th>
                <th class="th-sm">ID блюда
                </th>
                <th class="th-sm">Номер столика
                </th>
                <th class="th-sm">Количество
                </th>
            </tr>
        </thead>
        <tbody>

            <?php
                $conn = mysqli_connect("localhost", "root", "", "cafe");

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT orders.order_id, dishes.dish_id, orders.table_number, orders.amount 
                FROM orders INNER JOIN dishes on orders.dish_id = dishes.dish_id";
                
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {

                        echo "<tr><td>" . $row["order_id"]
                            . "</td><td>" . $row["dish_id"]
                            . "</td><td>" . $row["table_number"]
                            . "</td><td>" . $row["amount"]
                            . "</td></tr>";
                    }
                    echo "</tbody>";
                } else {
                    echo "0 results";
                }
                $conn->close();
            ?>
</body>

</html>