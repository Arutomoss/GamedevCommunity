drop database cafe;
create database cafe;
use cafe;

create table dishes(
dish_id int auto_increment primary key,
dish_name varchar(20),
dish_weight int,
dish_price int,
dish_categor varchar(20)
);

create table orders(
order_id int auto_increment primary key,
dish_id int,
	foreign key (dish_id) references dishes(dish_id) on delete cascade on update cascade,
table_number int,
amount int
);

insert into dishes(dish_name, dish_weight, dish_price, dish_categor) values ("Pasta", 200, 15, "garnir"),
																			("Borsh", 150, 10, "hot"),
																			("Kotleti", 100, 25, "main"),
																			("Sosiski", 80, 13, "main"),
																			("Pure", 120, 18, "garnir");

insert into orders(dish_id, table_number, amount) values    (1, 15, 1),
															(2, 10, 2),
															(3, 25, 3),
															(4, 13, 5),
															(5, 18, 1);