<?php 
	echo "posel ti lisiy!";
?>