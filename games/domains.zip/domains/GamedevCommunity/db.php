<?php
    require "libs/rb-mysql.php";
    R::setup( 'mysql:host=localhost;dbname=gamedev_db', 'root', '' );
?>