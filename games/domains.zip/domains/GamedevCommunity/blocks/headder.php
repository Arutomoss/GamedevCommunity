<link rel="stylesheet" href="css/style-news.css">

<header>
        <div class="h_container">
            <div class="logo"></div>

            <nav>
                <a href="../news.php">Новости</a>
                <a href="../messages.php">Сообщения</a>
                <a href="#">Jams</a>
            </nav>
        </div>
</header>